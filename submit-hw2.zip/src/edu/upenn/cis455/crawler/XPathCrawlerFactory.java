package edu.upenn.cis455.crawler;

public class XPathCrawlerFactory {
	public XPathCrawler getCrawler() {
		return new XPathCrawler();
	}
}
